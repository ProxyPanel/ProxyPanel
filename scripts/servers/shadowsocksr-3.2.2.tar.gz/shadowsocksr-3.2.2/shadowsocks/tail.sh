#!/bin/bash

tail -f ssserver.log
