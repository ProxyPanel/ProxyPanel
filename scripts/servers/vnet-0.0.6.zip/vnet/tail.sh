#!/bin/bash
cd `dirname $0`
tail -f vnet.log
