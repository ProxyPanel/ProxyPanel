#!/bin/bash
yum install -y wget vim && wget https://github.com/rc452860/vnet/releases/download/v0.0.6/vnet_linux_amd64 -O vnet && chmod a+x ./*